﻿namespace Domashka
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.TepT3A4 = new System.Windows.Forms.TextBox();
            this.TepT3A3 = new System.Windows.Forms.TextBox();
            this.TepT3A2 = new System.Windows.Forms.TextBox();
            this.TepT3A1 = new System.Windows.Forms.TextBox();
            this.TepT2A4 = new System.Windows.Forms.TextBox();
            this.TepT2A3 = new System.Windows.Forms.TextBox();
            this.TepT2A2 = new System.Windows.Forms.TextBox();
            this.TepT2A1 = new System.Windows.Forms.TextBox();
            this.TepT1A4 = new System.Windows.Forms.TextBox();
            this.TepT1A3 = new System.Windows.Forms.TextBox();
            this.TepT1A2 = new System.Windows.Forms.TextBox();
            this.TepT1A1 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PotA4 = new System.Windows.Forms.TextBox();
            this.PotA3 = new System.Windows.Forms.TextBox();
            this.PotA2 = new System.Windows.Forms.TextBox();
            this.PotA1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ZapT3 = new System.Windows.Forms.TextBox();
            this.ZapT2 = new System.Windows.Forms.TextBox();
            this.ZapT1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Vhodnie_danie = new System.Windows.Forms.TabPage();
            this.Grafick = new System.Windows.Forms.TabPage();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.Exit = new System.Windows.Forms.Button();
            this.Raschot = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.RasT1A1 = new System.Windows.Forms.TextBox();
            this.RasT1A2 = new System.Windows.Forms.TextBox();
            this.RasT1A3 = new System.Windows.Forms.TextBox();
            this.RasT1A4 = new System.Windows.Forms.TextBox();
            this.RasT2A1 = new System.Windows.Forms.TextBox();
            this.RasT2A2 = new System.Windows.Forms.TextBox();
            this.RasT2A3 = new System.Windows.Forms.TextBox();
            this.RasT2A4 = new System.Windows.Forms.TextBox();
            this.RasT3A1 = new System.Windows.Forms.TextBox();
            this.RasT3A2 = new System.Windows.Forms.TextBox();
            this.RasT3A3 = new System.Windows.Forms.TextBox();
            this.RasT3A4 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.X1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.X12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.Vhodnie_danie.SuspendLayout();
            this.Grafick.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.TepT3A4);
            this.groupBox1.Controls.Add(this.TepT3A3);
            this.groupBox1.Controls.Add(this.TepT3A2);
            this.groupBox1.Controls.Add(this.TepT3A1);
            this.groupBox1.Controls.Add(this.TepT2A4);
            this.groupBox1.Controls.Add(this.TepT2A3);
            this.groupBox1.Controls.Add(this.TepT2A2);
            this.groupBox1.Controls.Add(this.TepT2A1);
            this.groupBox1.Controls.Add(this.TepT1A4);
            this.groupBox1.Controls.Add(this.TepT1A3);
            this.groupBox1.Controls.Add(this.TepT1A2);
            this.groupBox1.Controls.Add(this.TepT1A1);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.PotA4);
            this.groupBox1.Controls.Add(this.PotA3);
            this.groupBox1.Controls.Add(this.PotA2);
            this.groupBox1.Controls.Add(this.PotA1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(587, 192);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Исходные данные";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // TepT3A4
            // 
            this.TepT3A4.Location = new System.Drawing.Point(513, 145);
            this.TepT3A4.Name = "TepT3A4";
            this.TepT3A4.Size = new System.Drawing.Size(53, 20);
            this.TepT3A4.TabIndex = 24;
            // 
            // TepT3A3
            // 
            this.TepT3A3.Location = new System.Drawing.Point(513, 114);
            this.TepT3A3.Name = "TepT3A3";
            this.TepT3A3.Size = new System.Drawing.Size(53, 20);
            this.TepT3A3.TabIndex = 23;
            // 
            // TepT3A2
            // 
            this.TepT3A2.Location = new System.Drawing.Point(513, 82);
            this.TepT3A2.Name = "TepT3A2";
            this.TepT3A2.Size = new System.Drawing.Size(53, 20);
            this.TepT3A2.TabIndex = 22;
            // 
            // TepT3A1
            // 
            this.TepT3A1.Location = new System.Drawing.Point(513, 51);
            this.TepT3A1.Name = "TepT3A1";
            this.TepT3A1.Size = new System.Drawing.Size(53, 20);
            this.TepT3A1.TabIndex = 21;
            // 
            // TepT2A4
            // 
            this.TepT2A4.Location = new System.Drawing.Point(418, 145);
            this.TepT2A4.Name = "TepT2A4";
            this.TepT2A4.Size = new System.Drawing.Size(53, 20);
            this.TepT2A4.TabIndex = 20;
            // 
            // TepT2A3
            // 
            this.TepT2A3.Location = new System.Drawing.Point(418, 114);
            this.TepT2A3.Name = "TepT2A3";
            this.TepT2A3.Size = new System.Drawing.Size(53, 20);
            this.TepT2A3.TabIndex = 19;
            // 
            // TepT2A2
            // 
            this.TepT2A2.Location = new System.Drawing.Point(418, 82);
            this.TepT2A2.Name = "TepT2A2";
            this.TepT2A2.Size = new System.Drawing.Size(53, 20);
            this.TepT2A2.TabIndex = 18;
            // 
            // TepT2A1
            // 
            this.TepT2A1.Location = new System.Drawing.Point(418, 51);
            this.TepT2A1.Name = "TepT2A1";
            this.TepT2A1.Size = new System.Drawing.Size(53, 20);
            this.TepT2A1.TabIndex = 17;
            // 
            // TepT1A4
            // 
            this.TepT1A4.Location = new System.Drawing.Point(332, 145);
            this.TepT1A4.Name = "TepT1A4";
            this.TepT1A4.Size = new System.Drawing.Size(53, 20);
            this.TepT1A4.TabIndex = 16;
            // 
            // TepT1A3
            // 
            this.TepT1A3.Location = new System.Drawing.Point(332, 114);
            this.TepT1A3.Name = "TepT1A3";
            this.TepT1A3.Size = new System.Drawing.Size(53, 20);
            this.TepT1A3.TabIndex = 15;
            // 
            // TepT1A2
            // 
            this.TepT1A2.Location = new System.Drawing.Point(332, 82);
            this.TepT1A2.Name = "TepT1A2";
            this.TepT1A2.Size = new System.Drawing.Size(53, 20);
            this.TepT1A2.TabIndex = 14;
            // 
            // TepT1A1
            // 
            this.TepT1A1.Location = new System.Drawing.Point(332, 51);
            this.TepT1A1.Name = "TepT1A1";
            this.TepT1A1.Size = new System.Drawing.Size(53, 20);
            this.TepT1A1.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(329, 13);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(245, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Теплотворная способность различных топлив ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(510, 26);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Топливо3";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(415, 26);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Топливо2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(329, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Топливо1";
            // 
            // PotA4
            // 
            this.PotA4.Location = new System.Drawing.Point(186, 145);
            this.PotA4.Name = "PotA4";
            this.PotA4.Size = new System.Drawing.Size(45, 20);
            this.PotA4.TabIndex = 8;
            // 
            // PotA3
            // 
            this.PotA3.Location = new System.Drawing.Point(186, 114);
            this.PotA3.Name = "PotA3";
            this.PotA3.Size = new System.Drawing.Size(45, 20);
            this.PotA3.TabIndex = 7;
            // 
            // PotA2
            // 
            this.PotA2.Location = new System.Drawing.Point(186, 82);
            this.PotA2.Name = "PotA2";
            this.PotA2.Size = new System.Drawing.Size(45, 20);
            this.PotA2.TabIndex = 6;
            // 
            // PotA1
            // 
            this.PotA1.Location = new System.Drawing.Point(186, 51);
            this.PotA1.Name = "PotA1";
            this.PotA1.Size = new System.Drawing.Size(45, 20);
            this.PotA1.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(120, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Потребности агрегатов в топливе, т";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 148);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Агрегат4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 117);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Агрегат3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Агрегат2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Агрегат1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ZapT3);
            this.groupBox2.Controls.Add(this.ZapT2);
            this.groupBox2.Controls.Add(this.ZapT1);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(7, 204);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(587, 113);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Запасы топлив";
            // 
            // ZapT3
            // 
            this.ZapT3.Location = new System.Drawing.Point(332, 55);
            this.ZapT3.Name = "ZapT3";
            this.ZapT3.Size = new System.Drawing.Size(53, 20);
            this.ZapT3.TabIndex = 16;
            // 
            // ZapT2
            // 
            this.ZapT2.Location = new System.Drawing.Point(258, 55);
            this.ZapT2.Name = "ZapT2";
            this.ZapT2.Size = new System.Drawing.Size(53, 20);
            this.ZapT2.TabIndex = 15;
            // 
            // ZapT1
            // 
            this.ZapT1.Location = new System.Drawing.Point(186, 55);
            this.ZapT1.Name = "ZapT1";
            this.ZapT1.Size = new System.Drawing.Size(45, 20);
            this.ZapT1.TabIndex = 14;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 58);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(143, 13);
            this.label13.TabIndex = 13;
            this.label13.Text = "Наличие сортов топлива, т";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(329, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Топливо3";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(255, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Топливо2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(183, 16);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 10;
            this.label10.Text = "Топливо1";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Vhodnie_danie);
            this.tabControl1.Controls.Add(this.Grafick);
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(804, 639);
            this.tabControl1.TabIndex = 2;
            // 
            // Vhodnie_danie
            // 
            this.Vhodnie_danie.Controls.Add(this.groupBox3);
            this.Vhodnie_danie.Controls.Add(this.groupBox1);
            this.Vhodnie_danie.Controls.Add(this.groupBox2);
            this.Vhodnie_danie.Location = new System.Drawing.Point(4, 22);
            this.Vhodnie_danie.Name = "Vhodnie_danie";
            this.Vhodnie_danie.Padding = new System.Windows.Forms.Padding(3);
            this.Vhodnie_danie.Size = new System.Drawing.Size(695, 536);
            this.Vhodnie_danie.TabIndex = 0;
            this.Vhodnie_danie.Text = "Входные данные";
            this.Vhodnie_danie.UseVisualStyleBackColor = true;
            this.Vhodnie_danie.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // Grafick
            // 
            this.Grafick.Controls.Add(this.chart3);
            this.Grafick.Controls.Add(this.chart2);
            this.Grafick.Controls.Add(this.dataGridView1);
            this.Grafick.Controls.Add(this.chart1);
            this.Grafick.Location = new System.Drawing.Point(4, 22);
            this.Grafick.Name = "Grafick";
            this.Grafick.Padding = new System.Windows.Forms.Padding(3);
            this.Grafick.Size = new System.Drawing.Size(796, 613);
            this.Grafick.TabIndex = 1;
            this.Grafick.Text = "График";
            this.Grafick.UseVisualStyleBackColor = true;
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(427, 6);
            this.chart1.Name = "chart1";
            series9.ChartArea = "ChartArea1";
            series9.Legend = "Legend1";
            series9.Name = "Агрегат1";
            series10.ChartArea = "ChartArea1";
            series10.Legend = "Legend1";
            series10.Name = "Агрегат2";
            series11.ChartArea = "ChartArea1";
            series11.Legend = "Legend1";
            series11.Name = "Агрегат3";
            series12.ChartArea = "ChartArea1";
            series12.Legend = "Legend1";
            series12.Name = "Агрегат4";
            this.chart1.Series.Add(series9);
            this.chart1.Series.Add(series10);
            this.chart1.Series.Add(series11);
            this.chart1.Series.Add(series12);
            this.chart1.Size = new System.Drawing.Size(363, 182);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            title3.Name = "Title1";
            title3.Text = "Количество толпива 1 ";
            this.chart1.Titles.Add(title3);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(679, 646);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(116, 31);
            this.Exit.TabIndex = 3;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Raschot
            // 
            this.Raschot.Location = new System.Drawing.Point(557, 646);
            this.Raschot.Name = "Raschot";
            this.Raschot.Size = new System.Drawing.Size(106, 31);
            this.Raschot.TabIndex = 4;
            this.Raschot.Text = "Расчёт";
            this.Raschot.UseVisualStyleBackColor = true;
            this.Raschot.Click += new System.EventHandler(this.Raschot_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(175, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 11;
            this.label14.Text = "Топливо1";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(255, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Топливо2";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(329, 29);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(56, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Топливо3";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(29, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Агрегат1";
            // 
            // RasT1A1
            // 
            this.RasT1A1.Location = new System.Drawing.Point(178, 54);
            this.RasT1A1.Name = "RasT1A1";
            this.RasT1A1.Size = new System.Drawing.Size(45, 20);
            this.RasT1A1.TabIndex = 25;
            // 
            // RasT1A2
            // 
            this.RasT1A2.Location = new System.Drawing.Point(178, 80);
            this.RasT1A2.Name = "RasT1A2";
            this.RasT1A2.Size = new System.Drawing.Size(45, 20);
            this.RasT1A2.TabIndex = 26;
            this.RasT1A2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // RasT1A3
            // 
            this.RasT1A3.Location = new System.Drawing.Point(178, 106);
            this.RasT1A3.Name = "RasT1A3";
            this.RasT1A3.Size = new System.Drawing.Size(45, 20);
            this.RasT1A3.TabIndex = 27;
            // 
            // RasT1A4
            // 
            this.RasT1A4.Location = new System.Drawing.Point(178, 132);
            this.RasT1A4.Name = "RasT1A4";
            this.RasT1A4.Size = new System.Drawing.Size(45, 20);
            this.RasT1A4.TabIndex = 28;
            // 
            // RasT2A1
            // 
            this.RasT2A1.Location = new System.Drawing.Point(258, 54);
            this.RasT2A1.Name = "RasT2A1";
            this.RasT2A1.Size = new System.Drawing.Size(45, 20);
            this.RasT2A1.TabIndex = 29;
            // 
            // RasT2A2
            // 
            this.RasT2A2.Location = new System.Drawing.Point(258, 80);
            this.RasT2A2.Name = "RasT2A2";
            this.RasT2A2.Size = new System.Drawing.Size(45, 20);
            this.RasT2A2.TabIndex = 30;
            // 
            // RasT2A3
            // 
            this.RasT2A3.Location = new System.Drawing.Point(258, 106);
            this.RasT2A3.Name = "RasT2A3";
            this.RasT2A3.Size = new System.Drawing.Size(45, 20);
            this.RasT2A3.TabIndex = 31;
            // 
            // RasT2A4
            // 
            this.RasT2A4.Location = new System.Drawing.Point(258, 132);
            this.RasT2A4.Name = "RasT2A4";
            this.RasT2A4.Size = new System.Drawing.Size(45, 20);
            this.RasT2A4.TabIndex = 32;
            // 
            // RasT3A1
            // 
            this.RasT3A1.Location = new System.Drawing.Point(332, 54);
            this.RasT3A1.Name = "RasT3A1";
            this.RasT3A1.Size = new System.Drawing.Size(45, 20);
            this.RasT3A1.TabIndex = 33;
            // 
            // RasT3A2
            // 
            this.RasT3A2.Location = new System.Drawing.Point(332, 80);
            this.RasT3A2.Name = "RasT3A2";
            this.RasT3A2.Size = new System.Drawing.Size(45, 20);
            this.RasT3A2.TabIndex = 34;
            // 
            // RasT3A3
            // 
            this.RasT3A3.Location = new System.Drawing.Point(332, 106);
            this.RasT3A3.Name = "RasT3A3";
            this.RasT3A3.Size = new System.Drawing.Size(45, 20);
            this.RasT3A3.TabIndex = 35;
            // 
            // RasT3A4
            // 
            this.RasT3A4.Location = new System.Drawing.Point(332, 132);
            this.RasT3A4.Name = "RasT3A4";
            this.RasT3A4.Size = new System.Drawing.Size(45, 20);
            this.RasT3A4.TabIndex = 36;
            this.RasT3A4.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(29, 83);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 13);
            this.label18.TabIndex = 37;
            this.label18.Text = "Агрегат2";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(29, 109);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 13);
            this.label19.TabIndex = 38;
            this.label19.Text = "Агрегат3";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(29, 135);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 13);
            this.label20.TabIndex = 39;
            this.label20.Text = "Агрегат4";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.RasT3A4);
            this.groupBox3.Controls.Add(this.RasT3A3);
            this.groupBox3.Controls.Add(this.RasT3A2);
            this.groupBox3.Controls.Add(this.RasT3A1);
            this.groupBox3.Controls.Add(this.RasT2A4);
            this.groupBox3.Controls.Add(this.RasT2A3);
            this.groupBox3.Controls.Add(this.RasT2A2);
            this.groupBox3.Controls.Add(this.RasT2A1);
            this.groupBox3.Controls.Add(this.RasT1A4);
            this.groupBox3.Controls.Add(this.RasT1A3);
            this.groupBox3.Controls.Add(this.RasT1A2);
            this.groupBox3.Controls.Add(this.RasT1A1);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.label15);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Location = new System.Drawing.Point(7, 323);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(587, 156);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Расчетные данные";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.X1,
            this.X2,
            this.X3,
            this.X5,
            this.X6,
            this.X7,
            this.X8,
            this.X9,
            this.X10,
            this.X11,
            this.X12});
            this.dataGridView1.Location = new System.Drawing.Point(0, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(408, 527);
            this.dataGridView1.TabIndex = 1;
            // 
            // X1
            // 
            this.X1.HeaderText = "X1";
            this.X1.Name = "X1";
            // 
            // X2
            // 
            this.X2.HeaderText = "X2";
            this.X2.Name = "X2";
            // 
            // X3
            // 
            this.X3.HeaderText = "X4";
            this.X3.Name = "X3";
            // 
            // X5
            // 
            this.X5.HeaderText = "X5";
            this.X5.Name = "X5";
            // 
            // X6
            // 
            this.X6.HeaderText = "X6";
            this.X6.Name = "X6";
            // 
            // X7
            // 
            this.X7.HeaderText = "X7";
            this.X7.Name = "X7";
            // 
            // X8
            // 
            this.X8.HeaderText = "X8";
            this.X8.Name = "X8";
            // 
            // X9
            // 
            this.X9.HeaderText = "X9";
            this.X9.Name = "X9";
            // 
            // X10
            // 
            this.X10.HeaderText = "X10";
            this.X10.Name = "X10";
            // 
            // X11
            // 
            this.X11.HeaderText = "X11";
            this.X11.Name = "X11";
            // 
            // X12
            // 
            this.X12.HeaderText = "X12";
            this.X12.Name = "X12";
            // 
            // chart2
            // 
            chartArea2.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart2.Legends.Add(legend2);
            this.chart2.Location = new System.Drawing.Point(427, 207);
            this.chart2.Name = "chart2";
            series5.ChartArea = "ChartArea1";
            series5.Legend = "Legend1";
            series5.Name = "Агрегат1";
            series6.ChartArea = "ChartArea1";
            series6.Legend = "Legend1";
            series6.Name = "Агрегат2";
            series7.ChartArea = "ChartArea1";
            series7.Legend = "Legend1";
            series7.Name = "Агрегат3";
            series8.ChartArea = "ChartArea1";
            series8.Legend = "Legend1";
            series8.Name = "Агрегат4";
            this.chart2.Series.Add(series5);
            this.chart2.Series.Add(series6);
            this.chart2.Series.Add(series7);
            this.chart2.Series.Add(series8);
            this.chart2.Size = new System.Drawing.Size(363, 182);
            this.chart2.TabIndex = 2;
            this.chart2.Text = "chart2";
            title2.Name = "Title1";
            title2.Text = "Количества топлива 2";
            this.chart2.Titles.Add(title2);
            // 
            // chart3
            // 
            chartArea1.Name = "ChartArea1";
            this.chart3.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart3.Legends.Add(legend1);
            this.chart3.Location = new System.Drawing.Point(427, 415);
            this.chart3.Name = "chart3";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Агрегат1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Агрегат2";
            series3.ChartArea = "ChartArea1";
            series3.Legend = "Legend1";
            series3.Name = "Агрегат3";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Агрегат4";
            this.chart3.Series.Add(series1);
            this.chart3.Series.Add(series2);
            this.chart3.Series.Add(series3);
            this.chart3.Series.Add(series4);
            this.chart3.Size = new System.Drawing.Size(363, 182);
            this.chart3.TabIndex = 3;
            this.chart3.Text = "chart3";
            title1.Name = "Title1";
            title1.Text = "Количество топлива 3";
            this.chart3.Titles.Add(title1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 680);
            this.Controls.Add(this.Raschot);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Теплотворная способность различных топлив ";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.Vhodnie_danie.ResumeLayout(false);
            this.Grafick.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox TepT3A4;
        private System.Windows.Forms.TextBox TepT3A3;
        private System.Windows.Forms.TextBox TepT3A2;
        private System.Windows.Forms.TextBox TepT3A1;
        private System.Windows.Forms.TextBox TepT2A4;
        private System.Windows.Forms.TextBox TepT2A3;
        private System.Windows.Forms.TextBox TepT2A2;
        private System.Windows.Forms.TextBox TepT2A1;
        private System.Windows.Forms.TextBox TepT1A4;
        private System.Windows.Forms.TextBox TepT1A3;
        private System.Windows.Forms.TextBox TepT1A2;
        private System.Windows.Forms.TextBox TepT1A1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox PotA4;
        private System.Windows.Forms.TextBox PotA3;
        private System.Windows.Forms.TextBox PotA2;
        private System.Windows.Forms.TextBox PotA1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox ZapT3;
        private System.Windows.Forms.TextBox ZapT2;
        private System.Windows.Forms.TextBox ZapT1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Vhodnie_danie;
        private System.Windows.Forms.TabPage Grafick;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Button Raschot;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox RasT3A4;
        private System.Windows.Forms.TextBox RasT3A3;
        private System.Windows.Forms.TextBox RasT3A2;
        private System.Windows.Forms.TextBox RasT3A1;
        private System.Windows.Forms.TextBox RasT2A4;
        private System.Windows.Forms.TextBox RasT2A3;
        private System.Windows.Forms.TextBox RasT2A2;
        private System.Windows.Forms.TextBox RasT2A1;
        private System.Windows.Forms.TextBox RasT1A4;
        private System.Windows.Forms.TextBox RasT1A3;
        private System.Windows.Forms.TextBox RasT1A2;
        private System.Windows.Forms.TextBox RasT1A1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn X1;
        private System.Windows.Forms.DataGridViewTextBoxColumn X2;
        private System.Windows.Forms.DataGridViewTextBoxColumn X3;
        private System.Windows.Forms.DataGridViewTextBoxColumn X5;
        private System.Windows.Forms.DataGridViewTextBoxColumn X6;
        private System.Windows.Forms.DataGridViewTextBoxColumn X7;
        private System.Windows.Forms.DataGridViewTextBoxColumn X8;
        private System.Windows.Forms.DataGridViewTextBoxColumn X9;
        private System.Windows.Forms.DataGridViewTextBoxColumn X10;
        private System.Windows.Forms.DataGridViewTextBoxColumn X11;
        private System.Windows.Forms.DataGridViewTextBoxColumn X12;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
    }
}

