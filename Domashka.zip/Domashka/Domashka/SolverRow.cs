﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domashka
{
    class SolverRow
    {


        public byte xId { get; set; }

        public double Koef { get; set; }

       
    }
}
